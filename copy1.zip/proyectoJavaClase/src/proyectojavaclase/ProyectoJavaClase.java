/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectojavaclase;

/**
 *
 * @author Usuario
 */
public class ProyectoJavaClase {
    private static void menuLogin(){
        System.out.println("+-------------+");
        System.out.println("| LOGIN BANCO |");
        System.out.println("+-------------+");
        System.out.println("\n1.");
        System.out.println("");
        System.out.println("");
        System.out.println("");
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
